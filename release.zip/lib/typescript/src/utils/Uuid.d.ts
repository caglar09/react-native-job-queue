export declare class Uuid {
    static v4(): string;
}
//# sourceMappingURL=Uuid.d.ts.map