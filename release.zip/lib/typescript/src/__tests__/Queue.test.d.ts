export interface Payload {
    test: string;
}
//# sourceMappingURL=Queue.test.d.ts.map